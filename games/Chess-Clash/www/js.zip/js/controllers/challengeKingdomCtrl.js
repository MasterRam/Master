controllers
  
   
.controller('challengeKingdomCtrl', function($scope) {

})
   
