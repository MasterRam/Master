controllers.controller('switchUserCtrl', function($scope) {

})
 