controllers.controller('giveUpBattleCtrl', function($scope) {

})
   
