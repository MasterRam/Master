controllers.controller('kingdomProfileCtrl', function($scope) {

})
