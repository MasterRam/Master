angular.module('app.constants', [])

.constant('chessConfig', {
	"url": "http://localhost",
	"port":"61305"
	
}).constant('chessStorage', {
	"user": "chess-login",
	"board":"chess-board"
	
}) ;