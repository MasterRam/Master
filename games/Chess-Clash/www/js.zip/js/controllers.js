var controllers=angular.module('app.controllers', [])
  /*
.controller('iGClashCtrl', function($scope) {

})
   
.controller('signupCtrl', function($scope) {

})
      
.controller('iG-BattleCtrl', function($scope) {

})
   
.controller('dashBoardCtrl', function($scope) {

})
   
.controller('kingdomProfileCtrl', function($scope) {

})
   
.controller('challengeKingdomCtrl', function($scope) {

})
   
.controller('requestLifeTimeCtrl', function($scope) {

})
   
.controller('giveUpBattleCtrl', function($scope) {

})
   
.controller('switchUserCtrl', function($scope) {

})
 */